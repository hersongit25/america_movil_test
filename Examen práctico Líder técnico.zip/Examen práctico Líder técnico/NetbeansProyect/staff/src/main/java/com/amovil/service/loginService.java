/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.amovil.service;

import com.amovil.jpa.user;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author herso
 */
public interface loginService {

    /**
     *
     */
    public List<user> getLogin(); 
//    public void 
}

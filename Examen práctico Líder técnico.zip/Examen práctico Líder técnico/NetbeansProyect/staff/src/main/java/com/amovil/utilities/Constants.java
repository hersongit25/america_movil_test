/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.amovil.utilities;

/**
 *
 * @author herso
 */
public abstract class Constants {
//    ========== ORCL Connection ==========
    public static String URL_DB = "jdbc:oracle:thin:@localhost:1521:developer";
    public static String USER_DB = "ATADB";
    public static String PASS_DB = "admin25";
}

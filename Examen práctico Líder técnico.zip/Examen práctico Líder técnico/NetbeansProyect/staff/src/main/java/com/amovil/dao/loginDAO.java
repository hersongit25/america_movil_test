/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.amovil.dao;

import com.amovil.jpa.user;
import java.util.List;

/**
 *
 * @author herso
 */
public interface loginDAO {
    
    public List<user> getListUser();
}

package com.amovil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaffApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}

CREATE TABLE c_descuento(
id_desc NUMBER(2) NOT NULL,
name_desc VARCHAR2(20) NOT NULL,
porcent_desc NUMBER(2,2) NOT NULL,
CONSTRAINT pk_descuento PRIMARY KEY(id_desc)
);


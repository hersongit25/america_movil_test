CREATE TABLE c_area_empleado(
id_area_emp NUMBER(4) NOT NULL,
name_area VARCHAR2(20) NOT NULL,
estatus_area NUMBER(1) NOT NULL,
CONSTRAINT pk_id_area PRIMARY KEY (id_area_emp)
);

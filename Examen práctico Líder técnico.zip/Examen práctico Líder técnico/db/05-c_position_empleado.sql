CREATE TABLE c_position_empleado(
id_position_emp NUMBER(4) NOT NULL,
name_position VARCHAR2(20) NOT NULL,
estatus_position NUMBER(1) NOT NULL,
CONSTRAINT pk_id_position PRIMARY KEY (id_position_emp)
);
